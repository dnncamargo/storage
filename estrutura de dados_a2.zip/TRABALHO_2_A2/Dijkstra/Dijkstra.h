#ifndef DIJKSTRA_H_INCLUDED
#define DIJKSTRA_H_INCLUDED
#include "GrafoM.h"

bool dijkstra(Grafo &grafo, char *origem, char *destino);

#endif // DIJKSTRA_H_INCLUDED
