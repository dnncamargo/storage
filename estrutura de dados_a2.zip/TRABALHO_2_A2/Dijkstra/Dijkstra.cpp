#include <stdio.h>
#include <limits.h>
#include "GrafoM.h"
#include "Pilha.h"

//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
bool temNaoVisitado(Grafo &grafo) {
    for (int i = 0; i < grafo.qtdVertices; i++)
        if (! grafo.vertices[i].processado)
            return true;

    return false;
}

//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
int menorEstimativa(Grafo &grafo) {
    int menor = INT_MAX;
    int pos = -1;

    for (int i = 0; i < grafo.qtdVertices; i++)
        if (! grafo.vertices[i].processado && grafo.vertices[i].estimativa < menor) {
            menor = grafo.vertices[i].estimativa;
            pos = i;
        }

    return pos;
}

//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
void inicializaDados(Grafo &grafo) {
    for (int i = 0; i < grafo.qtdVertices; i++) {
        grafo.vertices[i].processado = false;
        grafo.vertices[i].estimativa = INT_MAX;
        grafo.vertices[i].precedente = -1;
    }
}

//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
bool dijkstra(Grafo &grafo, char *origem, char *destino) {
    int pos_orig = buscaVertice(grafo, origem);
    int pos_dest = buscaVertice(grafo, destino);
    int k, s;
    Pilha pilha;
    char rotulo[TAM_ROTULO+1];

    if (pos_orig == -1 || pos_dest == -1)
        return false;

    inicializaDados(grafo);
    grafo.vertices[pos_orig].estimativa = 0;

    while (temNaoVisitado(grafo)) {
        k = menorEstimativa(grafo);
        grafo.vertices[k].processado = true;
        for (int j = 0; j < grafo.qtdVertices; j++)
            if (grafo.matriz[k][j] != 0 && ! grafo.vertices[j].processado) {
                s = grafo.vertices[k].estimativa + grafo.matriz[k][j];
                if (s < grafo.vertices[j].estimativa) {
                    grafo.vertices[j].estimativa = s;
                    grafo.vertices[j].precedente = k;
                }
            }
    }

    printf("Caminho (custo: %d):\n", grafo.vertices[pos_dest].estimativa);
    pilha = criaPilha();

    empilha(pilha, destino, TAM_ROTULO+1);

    while(pos_orig != pos_dest) {
        pos_dest = grafo.vertices[pos_dest].precedente;
        empilha(pilha, grafo.vertices[pos_dest].rotulo, TAM_ROTULO+1);
    }

    while (! vazia(pilha)) {
        desempilha(pilha, rotulo);
        printf("%s ", rotulo);
    }

    libera(pilha);

    return true;
}
