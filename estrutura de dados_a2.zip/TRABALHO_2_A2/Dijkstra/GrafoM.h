#ifndef GRAFOM_H_INCLUDED
#define GRAFOM_H_INCLUDED

const int TAM_ROTULO = 20;      // Tamanho m�ximo do r�tulo (em caracteres)

struct vertice {
    char rotulo[TAM_ROTULO+1];  // R�tulo do v�rtice
    bool processado;            // Indicador de v�rtice processado (usado nas buscas)
    int estimativa;
    int precedente;
};

typedef struct vertice Vertice;

struct grafo {
    bool orientado;	    // Indicador de grafo orientado
    bool ponderado;	    // Indicador de grafo ponderado
    int maxVertices;	// N�mero m�ximo bde v�rtices
    int qtdVertices;	// N�mero atual de v�rtices
    Vertice *vertices;	// Ponteiro para o vetor com os r�tulos dos v�rtices
    int **matriz;		// Ponteiro para a matriz de adjac�ncias
};

typedef struct grafo Grafo;

int buscaVertice(Grafo &grafo, char *rotulo);

// Cria um Grafo com espa�o para o n�mero de v�rtices especificado. O grafo
// pode ser orientado ou n�o e ponderado ou n�o.
Grafo criaGrafo(int maxVertices, bool orientado, bool ponderado);

// Cria um v�rtice no grafo com o r�tulo especificado.
// Se j� existir um v�rtice com esse r�tulo retorna FALSO.
bool criaVertice(Grafo &grafo, char *rotulo);

// Remove o v�rtice com o r�tulo especificado.
// Se n�o existir um v�rtice com esse r�tulo retorna FALSO.
bool removeVertice(Grafo &grafo, char *rotulo);

// Cria uma aresta com o peso especificado ligando dois v�rtices em um
// grafo ponderado. Se um dos v�rtices n�o existir ou o grafo for n�o
// ponderado retorna FALSO.
bool criaAresta(Grafo &grafo, char *origem, char *destino, int peso);

// Cria uma aresta ligando dois v�rtices em um grafo n�o ponderado. Se um
// dos v�rtices n�o existir ou o grafo for ponderado retorna FALSO.
bool criaAresta(Grafo &grafo, char *origem, char *destino);

// Remove a aresta que liga os dois v�rtices especificados. Se um
// dos v�rtices n�o existir retorna FALSO.
bool removeAresta(Grafo &grafo, char *origem, char *destino);

// Verifica se existe um v�rtice com o r�tulo especificado.
bool existeVertice(Grafo &grafo, char *rotulo);

// Verifica se existe uma aresta ligando os v�rtices especificados.
bool existeAresta(Grafo &grafo, char *origem, char *destino);

// Retorna o peso da aresta que liga os v�rtices especificados.
// Retorna 0 se n�o existe aresta ou se um dos v�rtices n�o existir.
int pesoAresta(Grafo &grafo, char *origem, char *destino);

// Percorre o grafo usando DFS a partir do v�rtice especificado.
void buscaProfundidade(Grafo &grafo, char *origem);

// Percorre o grafo usando BFS a partir do v�rtice especificado.
void buscaLargura(Grafo &grafo, char *origem);

// Libera a �rea de mem�ria usada pelo grafo.
void libera(Grafo &grafo);

#endif // GRAFOM_H_INCLUDED
