#include <stdlib.h>
#include <mem.h>
#include <stdio.h>
#include <string.h>
#include "GrafoM.h"
#include "Pilha.h"
#include "Fila.h"

//---------------------------------------------------------------------------------
// Busca um v�rtice e retorna sua posi��o no vetor ou -1 se n�o existir
//---------------------------------------------------------------------------------
int buscaVertice(Grafo &grafo, char *rotulo) {
    for (int i = 0; i < grafo.qtdVertices; i++)
        if (strcmp(grafo.vertices[i].rotulo, rotulo) == 0)
            return i;

    return -1;
}

//---------------------------------------------------------------------------------
// Marca todos os v�rtices como n�o processados para inciiar a busca
// em largura ou profundidade
//---------------------------------------------------------------------------------
void inicializaBusca(Grafo &grafo) {
    for (int i = 0; i < grafo.qtdVertices; i++)
        grafo.vertices[i].processado = false;
}

//---------------------------------------------------------------------------------
// Cria um Grafo com espa�o para o n�mero de v�rtices especificado. O grafo
// pode ser orientado ou n�o e ponderado ou n�o.
//---------------------------------------------------------------------------------
Grafo criaGrafo(int maxVertices, bool orientado, bool ponderado) {
    Grafo grafo;

    grafo.orientado   = orientado;
    grafo.ponderado   = ponderado;
    grafo.maxVertices = maxVertices;
    grafo.qtdVertices = 0;
    grafo.vertices    = (Vertice *) malloc(maxVertices * sizeof(Vertice));
    grafo.matriz      = (int **) malloc(maxVertices * sizeof(int *));

    for (int i = 0; i < maxVertices; i++) {
        grafo.matriz[i] = (int *) malloc(maxVertices * sizeof(int));
        memset(grafo.matriz[i], 0, maxVertices * sizeof(int));
    }

    memset(grafo.vertices, 0, maxVertices * sizeof(Vertice));

    return grafo;
}

//---------------------------------------------------------------------------------
// Cria um v�rtice no grafo com o r�tulo especificado.
// Se j� existir um v�rtice com esse r�tulo retorna FALSO.
//---------------------------------------------------------------------------------
bool criaVertice(Grafo &grafo, char *rotulo) {
    if (grafo.qtdVertices < grafo.maxVertices &&
        buscaVertice(grafo, rotulo) == -1) {
            strcpy(grafo.vertices[grafo.qtdVertices].rotulo, rotulo);
            grafo.qtdVertices++;
            return true;
    }

    return false;
}

//---------------------------------------------------------------------------------
// Remove o v�rtice com o r�tulo especificado.
// Se n�o existir um v�rtice com esse r�tulo retorna FALSO.
//---------------------------------------------------------------------------------
bool removeVertice(Grafo &grafo, char *rotulo) {
    int pos = buscaVertice(grafo, rotulo);

    if (pos == -1)
        return false;

    // Desloca uma linha para cima todas as linhas abaixo do v�rtice removido
    for (int i = pos; i < grafo.qtdVertices-1; i++)
        for (int j = 0; j < grafo.qtdVertices; j++)
            grafo.matriz[i][j] = grafo.matriz[i+1][j];

    // Desloca uma coluna para a esquerda todas as colunas � direita do v�rtice removido
    for (int j = pos; j < grafo.qtdVertices-1; j++)
        for (int i = 0; i < grafo.qtdVertices; i++)
            grafo.matriz[i][j] = grafo.matriz[i][j+1];

    // Desloca uma unidade para cima todos os v�rtices abaixo do v�rtice removido
    for (int i = pos; i < grafo.qtdVertices-1; i++)
        strcpy(grafo.vertices[i].rotulo, grafo.vertices[i+1].rotulo);

    grafo.qtdVertices--;
}

//---------------------------------------------------------------------------------
// Cria uma aresta com o peso especificado ligando dois v�rtices em um
// grafo ponderado. Se um dos v�rtices n�o existir ou o grafo for n�o
// ponderado retorna FALSO.
//---------------------------------------------------------------------------------
bool criaAresta(Grafo &grafo, char *origem, char *destino, int peso) {
    if (! grafo.ponderado)
        return false;

    int pos_orig = buscaVertice(grafo, origem);
    int pos_dest = buscaVertice(grafo, destino);

    if (pos_orig == -1 || pos_dest == -1)
        return false;

    grafo.matriz[pos_orig][pos_dest] = peso;

    // Se o grafo n�o � orientado ent�o a matriz deve ser sim�trica
    if (! grafo.orientado)
        grafo.matriz[pos_dest][pos_orig] = peso;

    return true;
}

//---------------------------------------------------------------------------------
// Cria uma aresta ligando dois v�rtices em um grafo n�o ponderado. Se um
// dos v�rtices n�o existir ou o grafo for ponderado retorna FALSO.
//---------------------------------------------------------------------------------
bool criaAresta(Grafo &grafo, char *origem, char *destino) {
    if (grafo.ponderado)
        return false;

    int pos_orig = buscaVertice(grafo, origem);
    int pos_dest = buscaVertice(grafo, destino);

    if (pos_orig == -1 || pos_dest == -1)
        return false;

    grafo.matriz[pos_orig][pos_dest]++;

    // Se o grafo n�o � orientado ent�o a matriz deve ser sim�trica
    if (! grafo.orientado && pos_orig != pos_dest)
        grafo.matriz[pos_dest][pos_orig]++;

    return true;
}

//---------------------------------------------------------------------------------
// Remove a aresta que liga os dois v�rtices especificados. Se um
// dos v�rtices n�o existir retorna FALSO.
//---------------------------------------------------------------------------------
bool removeAresta(Grafo &grafo, char *origem, char *destino) {
    int pos_orig = buscaVertice(grafo, origem);
    int pos_dest = buscaVertice(grafo, destino);

    if (pos_orig == -1 || pos_dest == -1)
        return false;

    if (grafo.ponderado) {
        grafo.matriz[pos_orig][pos_dest] = 0;

        // Se o grafo n�o � orientado ent�o a matriz deve ser sim�trica
        if (! grafo.orientado)
            grafo.matriz[pos_dest][pos_orig] = 0;
    }
    else {
        grafo.matriz[pos_orig][pos_dest]--;

        // Se o grafo n�o � orientado ent�o a matriz deve ser sim�trica
        if (! grafo.orientado && pos_orig != pos_dest)
            grafo.matriz[pos_dest][pos_orig]--;
    }
}

//---------------------------------------------------------------------------------
// Verifica se existe um v�rtice com o r�tulo especificado.
//---------------------------------------------------------------------------------
bool existeVertice(Grafo &grafo, char *rotulo) {
    return buscaVertice(grafo, rotulo) != -1;
}

//---------------------------------------------------------------------------------
// Verifica se existe uma aresta ligando os v�rtices especificados.
//---------------------------------------------------------------------------------
bool existeAresta(Grafo &grafo, char *origem, char *destino) {
    int pos_orig = buscaVertice(grafo, origem);
    int pos_dest = buscaVertice(grafo, destino);

    if (pos_orig == -1 || pos_dest == -1)
        return false;

    return grafo.matriz[pos_orig][pos_dest] != 0;
}

//---------------------------------------------------------------------------------
// Retorna o peso da aresta que liga os v�rtices especificados.
// Retorna 0 se n�o existe aresta ou se um dos v�rtices n�o existir.
//---------------------------------------------------------------------------------
int pesoAresta(Grafo &grafo, char *origem, char *destino) {
    if (! grafo.ponderado)
        return 0;

    int pos_orig = buscaVertice(grafo, origem);
    int pos_dest = buscaVertice(grafo, destino);

    if (pos_orig == -1 || pos_dest == -1)
        return 0;

    return grafo.matriz[pos_orig][pos_dest];
}

//---------------------------------------------------------------------------------
// Percorre o grafo usando DFS a partir do v�rtice especificado.
//---------------------------------------------------------------------------------
void buscaProfundidade(Grafo &grafo, char *origem) {
    Pilha pilha;
    char rotulo[TAM_ROTULO+1];
    int pos  = buscaVertice(grafo, origem);

    if (pos == -1)
        return;

    pilha = criaPilha();

    inicializaBusca(grafo);

    empilha(pilha, origem, strlen(origem)+1);
    grafo.vertices[pos].processado = true;

    while (! vazia(pilha)) {
        desempilha(pilha, rotulo);
        printf("%s ", rotulo);
        pos = buscaVertice(grafo, rotulo);
        for (int i = 0; i < grafo.qtdVertices; i++) {
            if (grafo.matriz[pos][i] > 0 && ! grafo.vertices[i].processado) {
                empilha(pilha, grafo.vertices[i].rotulo, TAM_ROTULO+1);
                grafo.vertices[i].processado = true;
            }
        }
    }

    libera(pilha);
}

//---------------------------------------------------------------------------------
// Percorre o grafo usando BFS a partir do v�rtice especificado.
//---------------------------------------------------------------------------------
void buscaLargura(Grafo &grafo, char *origem) {
    Fila fila;
    char rotulo[TAM_ROTULO+1];
    int pos = buscaVertice(grafo, origem);

    if (pos == -1)
        return;

    inicializaBusca(grafo);

    fila = criaFila();

    insere(fila, origem, strlen(origem)+1);
    grafo.vertices[pos].processado = true;

    while (! vazia(fila)) {
        remove(fila, rotulo);
        printf("%s ", rotulo);
        pos = buscaVertice(grafo, rotulo);
        for (int i = 0; i < grafo.qtdVertices; i++) {
            if (grafo.matriz[pos][i] > 0 && ! grafo.vertices[i].processado) {
                insere(fila, grafo.vertices[i].rotulo, TAM_ROTULO+1);
                grafo.vertices[i].processado = true;
            }
        }
    }

    libera(fila);
}

//---------------------------------------------------------------------------------
// Libera a �rea de mem�ria usada pelo grafo.
//---------------------------------------------------------------------------------
void libera(Grafo &grafo) {

    for (int i = 0; i < grafo.maxVertices; i++)
        free(grafo.matriz[i]);

    if (grafo.vertices)
        free(grafo.vertices);

    if (grafo.matriz)
        free(grafo.matriz);
}
