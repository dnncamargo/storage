#include <stdio.h>
#include <ctype.h>
#include "Dijkstra.h"

int main()
{
    Grafo grafo;
    char pond, orient, cont, origem[50], destino[50], path[100];
    FILE *f;
    int numVertices, peso;
    bool ponderado, orientado;

    printf("Arquivo: ");
    gets(path);

    f = fopen(path, "r");

    if (f == NULL) {
        puts("Arquivo n�o encontrado!");
        return 1;
    }

    fscanf(f, "%d %c %c\n", &numVertices, &orient, &pond);

    orientado = toupper(orient) == 'S';
    ponderado = toupper(pond) == 'S';

    if (! ponderado) {
        puts("Para calcular rotas o grafo tem que ser ponderado!");
        return 1;
    }

    grafo = criaGrafo(numVertices, orientado, ponderado);

    for (int i = 0; i < numVertices; i++) {
        fscanf(f, "%s\n", origem);
        criaVertice(grafo, origem);
    }

    do {
        if (ponderado) {
            fscanf(f, "%s %s %d\n", origem, destino, &peso);
            criaAresta(grafo, origem, destino, peso);
        }
        else {
            fscanf(f, "%s %s\n", origem, destino);
            criaAresta(grafo, origem, destino);
        }
    } while (! feof(f));

    fclose(f);

    do {
        printf("Vertice origem: ");
        gets(origem);

        if (! existeVertice(grafo, origem))
            puts("Origem nao existe no grafo.");
        else {
            printf("Vertice destino: ");
            gets(destino);

            if (! existeVertice(grafo, destino))
                puts("Destino nao existe no grafo.");
            else {
                dijkstra(grafo, origem, destino);
            }
        }

        printf("\n\nCalcula nova rota (S/N)? ");
        cont = toupper(getchar());
        getchar(); // Le o ENTER
    } while (cont == 'S');

    libera(grafo);
}
