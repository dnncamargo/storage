package com.uva.pdm.pdm_proj_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.uva.pdm.pdm_proj_app.QuizContract.QuestionsTable;

import java.util.ArrayList;
import java.util.List;

public class DataBaseOpenHelper extends SQLiteOpenHelper {

    private static String DATABASE_NAME ="quiz.db";
    private static int DATABASE_VERSION = 1;
    private static SQLiteDatabase db;

    public DataBaseOpenHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        this.db = db;

        final String SQL_CREATE_QUESTIONS_TABLE = "CREATE TABLE " +

                QuestionsTable.TABLE_NAME + " ( " +
                QuestionsTable._ID + "  INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuestionsTable.COLUMN_QUESTION + " TEXT, " +
                QuestionsTable.COLUMN_OPTION1 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION2 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION3 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION4 + " TEXT, " +
                QuestionsTable.COLUMN_ANSWER + " INTEGER" +
                ")";

        db.execSQL(SQL_CREATE_QUESTIONS_TABLE);
        fillQuestionsTable();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + QuestionsTable.TABLE_NAME);
        onCreate(db);
    }

    private void fillQuestionsTable() {
        Question q1 = new Question("A está correta", "A", "B", "C", "D", 1);
        Question q2 = new Question("B está correta", "A", "B", "C", "D", 2);
        Question q3 = new Question("C está correta", "A", "B", "C", "D", 3);
        Question q4 = new Question("D está correta", "A", "B", "C", "D", 4);

        addQuestion(q1);
        addQuestion(q2);
        addQuestion(q3);
        addQuestion(q4);
    }

    public List<Question> getAllQuestions() {
        List<Question> qlist = new ArrayList<>();
        db = getReadableDatabase();
        Cursor crs = db.rawQuery("SELECT * FROM " + QuestionsTable.TABLE_NAME, null);
        if(crs.moveToFirst()) {
            do {
                Question question = new Question();
                question.setQuestion(crs.getString(crs.getColumnIndex("question")));
                question.setOption1(crs.getString(crs.getColumnIndex("option1")));
                question.setOption2(crs.getString(crs.getColumnIndex("option2")));
                question.setOption3(crs.getString(crs.getColumnIndex("option3")));
                question.setOption4(crs.getString(crs.getColumnIndex("option4")));
                question.setNranswer(crs.getInt(crs.getColumnIndex("answer_nr")));
                qlist.add(question);
            } while (crs.moveToNext());
        }
        crs.close();
        db.close();
        return qlist;
    }

    private void addQuestion(Question question) {
        ContentValues cv = new ContentValues();
        cv.put(QuestionsTable.COLUMN_QUESTION, question.getQuestion());
        cv.put(QuestionsTable.COLUMN_OPTION1, question.getOption1());
        cv.put(QuestionsTable.COLUMN_OPTION2, question.getOption2());
        cv.put(QuestionsTable.COLUMN_OPTION3, question.getOption3());
        cv.put(QuestionsTable.COLUMN_OPTION4, question.getOption4());
        cv.put(QuestionsTable.COLUMN_ANSWER, question.getNranswer());
        db.insert(QuestionsTable.TABLE_NAME, null, cv);
    }
}