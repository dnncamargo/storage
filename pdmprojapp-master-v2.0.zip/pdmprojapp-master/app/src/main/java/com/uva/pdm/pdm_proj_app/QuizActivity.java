package com.uva.pdm.pdm_proj_app;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class QuizActivity extends AppCompatActivity {
    public static final String EXTRA_SCORE = "extraScore";
    private static final long COUNTDOWN_IN_MILLIS = 30000;

    private TextView textViewQuestion;
    private TextView textViewScore;
    private TextView textViewQuestionCounter;
    private TextView textViewCountDown;
    private RadioGroup rb_options;
    private RadioButton rb1;
    private RadioButton rb2;
    private RadioButton rb3;
    private RadioButton rb4;
    private RadioButton radio_choosen;
    private Button button_next;

    private ColorStateList txtColorDefaultRB;
    private ColorStateList txtColorDefaultCD;

    private CountDownTimer countDownTimer;
    private long timeLeftInMills;

    private List<Question> quizList;
    private int questionCounter;
    private int questionCounterTotal;
    private Question currentQuestion;

    private int score;
    private boolean answered;

    private long backPressedTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        textViewQuestion = (TextView) findViewById(R.id.textviewquestion);
        textViewScore = (TextView) findViewById(R.id.textviewcurrentscore);
        textViewCountDown = (TextView) findViewById(R.id.textviewcountdown);
        textViewQuestionCounter = (TextView) findViewById(R.id.textviewquestioncounter);

        button_next = (Button) findViewById(R.id.button_next);
        rb_options = (RadioGroup) findViewById(R.id.rgroup);
        rb1 = (RadioButton) findViewById(R.id.chbutton_qalt1);
        rb2 = (RadioButton) findViewById(R.id.chbutton_qalt2);
        rb3 = (RadioButton) findViewById(R.id.chbutton_qalt3);
        rb4 = (RadioButton) findViewById(R.id.chbutton_qalt4);

        txtColorDefaultRB = rb1.getTextColors();
        txtColorDefaultCD = textViewCountDown.getTextColors();

        DataBaseOpenHelper dbReader = new DataBaseOpenHelper(this);
        quizList = dbReader.getAllQuestions();
        questionCounterTotal = quizList.size();
        Collections.shuffle(quizList);

        showNextQuestion();
        button_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!answered) {
                    if(rb1.isChecked() || rb2.isChecked() || rb3.isChecked() || rb4.isChecked()) {
                        checkAnswer();
                    } else {
                        Toast t = Toast.makeText(QuizActivity.this, "Por favor, selecione uma pergunta", Toast.LENGTH_SHORT);
                    }
                } else {
                    showNextQuestion();
                }
            }
        });
    }

    private void checkAnswer(){
        answered = true;
        countDownTimer.cancel();

        radio_choosen = (RadioButton) findViewById(rb_options.getCheckedRadioButtonId());
        int answerNr = rb_options.indexOfChild(radio_choosen) + 1;

        if(answerNr == currentQuestion.getNranswer()) {
            score++;
            textViewScore.setText("Score: " + score);
        }

        showSolution();
    }

    private void showSolution(){
        rb1.setTextColor(Color.RED);
        rb2.setTextColor(Color.RED);
        rb3.setTextColor(Color.RED);
        rb4.setTextColor(Color.RED);

        switch (currentQuestion.getNranswer()) {
            case 1:
                rb1.setTextColor(Color.GREEN);
                textViewQuestion.setText("Resposta A está certa");
                break;

            case 2:
                rb2.setTextColor(Color.GREEN);
                textViewQuestion.setText("Resposta B está certa");
                break;

            case 3:
                rb3.setTextColor(Color.GREEN);
                textViewQuestion.setText("Resposta C está certa");
                break;

            case 4:
                rb4.setTextColor(Color.GREEN);
                textViewQuestion.setText("Resposta D está certa");
                break;
        }

        if(questionCounter < questionCounterTotal) {
            button_next.setText("Próxima");
        } else {
            button_next.setText("Finalizar");
        }
    }

    private void showNextQuestion(){
        rb1.setTextColor(txtColorDefaultRB);
        rb2.setTextColor(txtColorDefaultRB);
        rb3.setTextColor(txtColorDefaultRB);
        rb4.setTextColor(txtColorDefaultRB);
        rb_options.clearCheck();

        //Se ainda existem perguntas
        if(questionCounter < questionCounterTotal) {
            // Recuperar próxima pergunta
            currentQuestion = quizList.get(questionCounter);
            textViewQuestion.setText(currentQuestion.getQuestion());

            rb1.setText(currentQuestion.getOption1());
            rb2.setText(currentQuestion.getOption2());
            rb3.setText(currentQuestion.getOption3());
            rb4.setText(currentQuestion.getOption4());
            questionCounter++;

            textViewQuestionCounter.setText("Questão " + questionCounter + "/" + questionCounterTotal);
            answered = false;
            button_next.setText("Confirma");

            timeLeftInMills = COUNTDOWN_IN_MILLIS;
            startCountDown();
        } else {
            finishQuiz();
        }
    }

    public void finishQuiz(){
        Intent resultIntent = new Intent();
        resultIntent.putExtra(EXTRA_SCORE, score);
        setResult(RESULT_OK, resultIntent);
        finish();
    }

    public void startCountDown() {
        countDownTimer = new CountDownTimer(timeLeftInMills, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeftInMills = millisUntilFinished;
                updateCountDown();
            }

            @Override
            public void onFinish() {
                timeLeftInMills = 0;
                updateCountDown();
                checkAnswer();
            }
        }.start();
    }

    public void updateCountDown() {
        int minutes = (int) (timeLeftInMills / 1000)/ 60;
        int seconds = (int) (timeLeftInMills / 1000)% 60;
        String timeFormated = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
        textViewCountDown.setText(timeFormated);

        if(timeLeftInMills < 10000) {
            textViewCountDown.setTextColor(Color.RED);
        } else {
            textViewCountDown.setTextColor(txtColorDefaultCD);
        }
    }

    @Override
    public void onBackPressed() {
        if(backPressedTime + 2000 > System.currentTimeMillis()) {
            finishQuiz();
        } else {
            Toast.makeText(this, "Pressione novamente para finalizar", Toast.LENGTH_SHORT).show();
        }
        backPressedTime = System.currentTimeMillis();
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        if(countDownTimer != null) {
            countDownTimer.cancel();
        }
    }
}
