#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

 typedef struct avlNo{
	int info;
	avlNo *esq;
	avlNo *dir;
	int fatBal;
}AvlNo ;  

bool status = false;

void createNode (AvlNo * &raiz, int elem){
	raiz = new avlNo;
	raiz->info = elem;
	raiz->esq = NULL;
	raiz->dir = NULL;
	raiz->fatBal = 0;
}
void rotacionarDir (AvlNo * &a, bool &status) {
	avlNo *b, *c;
	b = a->esq;
	if (b->fatBal == -1) { // rota��o simples
		a->esq = b->dir;
		b->dir = a;
		a->fatBal = 0;
		a = b;
}
	else { // rota��o dupla
			c = b->dir;
			b->dir = c->esq;
			c->esq = b;
			a->esq = c->dir;
			c->dir = a;
			if (c->fatBal == -1)
					a->fatBal = 1;
			else a->fatBal = 0;
			
			if (c->fatBal == 1)
					b->fatBal = -1;
			else b->fatBal = 0;
			a = c;
		}
		a->fatBal = 0;
		status = false;
}

void rotacionarEsq (AvlNo * &a, bool &status) {
		AvlNo * b, * c;
		b = a->dir;
		if (b->fatBal == 1) { // rota��o simples
			a->dir = b->esq;
			b->esq = a;
			a->fatBal = 0;
			a = b;
		}
			else { // rota��o dupla
					c = b->esq;
					b->esq = c->dir;
					c->dir = b;
					a->dir = c->esq;
					c->esq = a;
					if (c->fatBal == 1)
						a->fatBal = -1;
						else a->fatBal = 0;
					if (c->fatBal == -1)
						b->fatBal = 1;
					else
						b->fatBal = 0;
						a = c;
				}
				a->fatBal = 0;
				status = false;
}
void insereAvl (AvlNo * &raiz, int elem, bool &status) {
	if (raiz == NULL) {
		createNode(raiz,elem);
		status = true;
	}else if (elem == raiz->info){
				printf ("Elemento repetido. \n");
				return;
			}else if (elem < raiz->info){
						insereAvl(raiz->esq,elem,status);
						if (status == true)
							switch (raiz->fatBal) {
									case 1 : raiz->fatBal = 0; status = false; break;
									case 0 : raiz->fatBal = -1; break;
									case -1 : rotacionarDir(raiz, status); break;
								}	
					} else {
								insereAvl(raiz->dir,elem,status);
								if (status == true)
								    switch (raiz->fatBal) {
										case -1 : raiz->fatBal = 0; status = false; break;
										case 0 : raiz->fatBal = 1; break;
										case 1 : rotacionarEsq(raiz,status); break;
									}
								}
							}


int main(){
	
	AvlNo * raiz = NULL;
	createNode(raiz,20);
	printf("****");

	return 0;
}
	
	
	
