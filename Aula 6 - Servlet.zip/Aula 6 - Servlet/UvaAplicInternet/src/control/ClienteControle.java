package control;

import java.io.IOException;
import java.util.GregorianCalendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.Cliente;
import persistence.UtilsBanco;

/**
 * Servlet implementation class ClienteControle
 */
@WebServlet({"/ClienteControle", "/cadcliente", 
	"/conscliente", "/altcliente","/excliente","/listarclientes"})
public class ClienteControle extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public ClienteControle() {
        super();   
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	execute(request, response);
	}

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		execute(request, response);
	}
    
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = request.getServletPath();
		String nome = request.getParameter("nome");
		String email = request.getParameter("email");
		String cpf = request.getParameter("cpf");
		String telefone = request.getParameter("tel");
		String dataNascimento = request.getParameter("dtnasc");
		String sexo = request.getParameter("rbsexo");
		String logradouro = request.getParameter("logradouro");
		String numero = request.getParameter("numero");
		String cep = request.getParameter("cep");
		String complemento = request.getParameter("complemento");
		String cidade = request.getParameter("cidade");
		String uf = request.getParameter("uf");
		String observacoes = request.getParameter("obs");
		System.out.println(url);
		Cliente c = new Cliente();
		c.setDataCadastro(new GregorianCalendar());
		c.setNome(nome);
		c.setEmail(email);
		c.setCpf(cpf);
		c.setTelefone(telefone);
		c.setDataNascimento(UtilsBanco.converterData(dataNascimento));
		c.setSexo(sexo);
		c.setLogradouro(logradouro);
		c.setNumero(new Integer(numero));
		c.setCep(cep);
		c.setComplemento(complemento);
		c.setCidade(cidade);
		c.setUf(uf);
		c.setObservacoes(observacoes);
		System.out.println(c);
		System.out.println(UtilsBanco.converterDataToBanco(c.getDataCadastro()));
	}
}
