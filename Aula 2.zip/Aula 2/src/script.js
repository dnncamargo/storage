/*
 * Arquivo Java Script (Sem uso de JQUERY) * 
 * 
 */
/* FUNÇÃO: validarDadosObrigatorios 
 * OBJETIVO: verificar se todos os campos obrigatórios do form Aluno foram informados pelo usuário*/
function validarDadosObrigatorios(form){
    	
    if (form.nome.value === ""){
        alert("Informe o nome completo.");
	form.nome.focus();
    }else if (form.email.value === ""){
        alert("Informe o e-mail.");
        form.email.focus();        
    }else if (form.cpf.value === ""){
        alert("Informe o número do CPF.");
        form.cpf.focus();
    }else if (form.tel.value === ""){
        alert("Informe o número telefone.");
        form.tel.focus();
    }else if (!form.rbsexo[0].checked && !form.rbsexo[1].checked){
        alert("Informe o sexo.");        
        return false;
    }else if (form.dtnasc.value === ""){
        alert("Informe a data de nascimento.");
        form.dtnasc.focus();
    }else if (form.logradouro.value === ""){
    	alert("Informe o logradouro.");
    	form.logradouro.focus();
    }else if (form.numero.value === ""){
    	alert("Informe o número.");
    	form.numero.focus();    
    }else if (form.cidade.value === ""){
	alert("Informe a cidade.");
	form.cidade.focus();
    }else if (form.cbouf.selectedIndex === 0){
    	form.cbouf.focus();
    	alert("Informe o estado.");    	
    }else if (form.cep.value === ""){
    	alert("Informe o número do CEP.");
    	form.cep.focus();
    }
    
    return false;
}

/* Validar o campo CEP, conforme a expressão regular definida */ 
function validarCEP(cep){
        exp = /\d{2}\.\d{3}\-\d{3}/;
        if(!exp.test(cep.value)){
	    cep.value = "";
            alert('Numero de Cep Inválido');               
	}
}

/* Validar o campo CPF, conforme a expressão regular definida */ 
function validarCPF(cpf){
        exp = /\d{3}\.\d{3}\.\d{3}\-\d{2}/;
        if(!exp.test(cpf.value)){
   	  cpf.value = "";
          alert('Numero do CPF Inválido');               
	}
}

/*Validar o campo telefone, usando a expressão regular definida */
function validarTelefone(tel){
        exp = /\(\d{2}\)\ \d{4,5}\-\d{4}/;
        /* o método exec retorna o valor pesquisado
         * o test retorna true ou false*/
        if(!exp.test(tel.value)){
                tel.value = "";
                alert('Numero de Telefone Inválido!');
        }
}


/* Validar o campo data, conforme a expressão regular definida */ 
function validarData(data){
        //alert('Data Invalida!'); 
        exp = /\d{2}\/\d{2}\/\d{4}/;
        /*     \/ – Uma barra literal  */
        if(exp.test(data.value)){
            var dia = data.value.substring(0,2);
            var mes = data.value.substring(3,5);
            var ano = data.value.substring(6,10);
            
            if((dia < 1) || (dia > 31)){
                alert('Data Invalida!');
            }else if((mes < 1) || (mes>12)){
                alert('Data Invalida!');
            }else if(ano<=1900){
                alert('Data Inválida!');
            }                  
        }
        else{
            data.value ="";
            alert('Data Invalida!');
        }       
}

/* Validar o campo e-mail, conforme a expressão regular definida */ 
function validarEmail(email){

    /*A expressão regular abaixo veio da especificação do HTML5*/
    var filtro = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
    /*
     * Explicação da expressão regular
     * 
     * 
     * outras expressões: 
     * [_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+).(\.[a-z]{2,3})$
     * ^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$
     *
     * (+) Casa o elemento precedente uma ou mais vezes. Por exemplo, ba+ casa
     *  "ba", "baa", "baaa", e assim por diante.
     * (\) Escape - anula o significado especial do metacaractere seguinte;
     * por exemplo, \. representa apenas um ponto.
     * (^) Casa o começo da cadeia de caracteres. Numa situação de múltiplas
     * linhas, casa o começo das linhas.
     * Logo percebe-se que as âncoras não casam pedaços do texto, elas servem 
     * apenas como uma referência.
     * ($) Casa o fim da cadeia de caracteres ou a posição logo antes da quebra
     * de linha do fim da cadeia.
     * Numa situação de múltiplas linhas, casa o fim das linhas.
     * (*) Coincidência dos caracteres precedidos ZERO ou mais vezes.  
     *   */
    
    if(filtro.test(email.value)) {
        return true;
    } else {
        email.value = "";
        return alert("E-mail inválido");
    }
    
}

/* Verificar se um campo só contém dígitos numéricos */
function validarDigNum(valor) {    
	
	if (!isNaN(valor.value)){
		return true;
	}else{
		valor.value = "";
        return alert("Este campo admite apenas números");
	}

}

/*Validar o tamanho do campo nome*/
function validarTamNome(nome){
	if (nome.value.length >= 4){
		return true;
	}else{		
        return alert("Informe ao menos 4 caracteres");
	}
}

/* Limpar os campos dentro de uma área/div */ /* Aula - 5 */
function limparCampos(area){
    
   /*pegar todos os elementos (neste caso campos) dentro de uma área informada*/
    var elementos = document.getElementById(area).querySelectorAll('*');
    for(var i = 0; i<elementos.length;i++){  
        switch (elementos[i].type) {
               case "text":
               case "textarea":
               case "password":               	   
                    elementos[i].value="";
                    break;
               case "file":	   
                   elementos[i].value="";                   
               case "select-one":
                    elementos[i].selectedIndex = 0;
                    break;
               case "radio":
               case "checkbox":
                    elementos[i].checked = false;
				break;
        }
    }   
}
