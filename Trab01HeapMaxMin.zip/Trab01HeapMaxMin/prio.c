#include <stdio.h>
#include <stdlib.h>
#include "prio.h"

/*
 * Function: create(int)
 * -----------------------------------
 *   Cria a estrutura principal
 *
 *   @param tamanho total do vetor
 *   @returns ponteiro para a estrutura criada
 */
Fprio* create(int length) {

    // criar a estrutura principal
    Fprio* fp = malloc (sizeof(Fprio));

    // criar os nodos do vetor
    fp-> vdata = malloc (sizeof(Node) * length);
    fp-> n = 0;
    fp-> len = length;
    return fp;
}

/*
 * Function: insert(Fprio*, Node)
 * -----------------------------------
 *   Funcao para inserir elemento
 *
 *   @param fp Ponteiro para a estrutura principal
 *   @param item Elemento a ser inserido
 *   @returns void
 */
void insertnode(Fprio* fp, Node* item) {
    Node* obj = item;
    fp-> vdata[fp-> n] = item;
    fp-> n++;
}

/*
 * Function: Node* createnode(float, int)
 * -----------------------------------
 *   Funcao para criar novo Node e atribuir valores informados por parametro
 *
 *   @param val Valor do elemento
 *   @param prio Prioridade do Node
 *   @returns Node*
 */
Node* createnode(float val, int prio) {
    Node* n = malloc (sizeof(Node));
    n-> value = val;
    n-> priority = prio;
    return n;
}

/*
 * Function: Node* extractmax(Fprio*)
 * -----------------------------------
 *   Funcao para extrair Node de maior prioridade da lista e retornar seu ponteiro
 *
 *   @param fp Ponteiro para a estrutura principal
 *   @returns Node*
 */
Node* extractmax(Fprio* fp) {
	int i, max = 0;
    // Percorre o vetor por todos os elementos existentes
	for (i = 1; i < fp-> n; i++){
        // Condicao para descobrir elemento com maior prioridade e armazenar indice em max
		if (fp-> vdata[max]-> priority < fp-> vdata[i]-> priority)
			max = i;
	}
    printf("%d\n",fp-> vdata[max]-> priority);
    // Realizar troca de Nodes por ponteiro (n-1 para que nao acesse a posicao vdata[-1])
	swap ((fp-> vdata[max]), (fp-> vdata[fp-> n-1]));
	fp-> n--;
	return fp-> vdata[fp-> n];
}

void swap(Node* na, Node* nb) {
    Node* nc = na;
    *na = *nb;
    *nb = *nc;
}
