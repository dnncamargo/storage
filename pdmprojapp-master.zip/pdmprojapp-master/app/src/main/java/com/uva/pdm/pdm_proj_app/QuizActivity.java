package com.uva.pdm.pdm_proj_app;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Collections;
import java.util.List;

public class QuizActivity extends AppCompatActivity {

    private TextView textViewQuestion;
    private TextView textViewScore;
    private TextView textViewQuestionCounter;
    private TextView textViewQuestionCountDown;
    private RadioGroup rb_options;
    private RadioButton rb1;
    private RadioButton rb2;
    private RadioButton rb3;
    private RadioButton rb4;
    private RadioButton radio_choosen;
    private Button button_next;

    private ColorStateList txtColorDefaultRB;

    private List<Question> quizList;
    private int questionCounter;
    private int questionCounterTotal;
    private Question currentQuestion;

    private int score;
    private boolean answered;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        textViewQuestion = (TextView) findViewById(R.id.textviewquestion);
        textViewScore = (TextView) findViewById(R.id.textviewcurrentscore);
        textViewQuestionCountDown = (TextView) findViewById(R.id.textviewcountdown);
        textViewQuestionCounter = (TextView) findViewById(R.id.textviewquestioncounter);

        button_next = (Button) findViewById(R.id.button_next);
        rb_options = (RadioGroup) findViewById(R.id.rgroup);
        rb1 = (RadioButton) findViewById(R.id.chbutton_qalt1);
        rb2 = (RadioButton) findViewById(R.id.chbutton_qalt2);
        rb3 = (RadioButton) findViewById(R.id.chbutton_qalt3);
        rb4 = (RadioButton) findViewById(R.id.chbutton_qalt4);

        txtColorDefaultRB = rb1.getTextColors();

        DataBaseOpenHelper dbReader = new DataBaseOpenHelper(this);
        quizList = dbReader.getAllQuestions();
        questionCounterTotal = quizList.size();
        Collections.shuffle(quizList);

        showNextQuestion();
        button_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!answered) {
                    if(rb1.isChecked() || rb2.isChecked() || rb3.isChecked() || rb4.isChecked()) {
                        checkAnswer();
                    } else {
                        Toast t = Toast.makeText(QuizActivity.this, "Por favor, selecione uma pergunta", Toast.LENGTH_SHORT);
                    }
                } else {
                    showNextQuestion();
                }
            }
        });
    }

    private void checkAnswer(){
        answered = true;
        radio_choosen = (RadioButton) findViewById(rb_options.getCheckedRadioButtonId());
        int answerNr = rb_options.indexOfChild(radio_choosen) + 1;

        if(answerNr == currentQuestion.getNranswer()) {
            score++;
            textViewScore.setText("Score: " + score);
        }

        showSolution();
    }

    private void showSolution(){
        rb1.setTextColor(Color.RED);
        rb2.setTextColor(Color.RED);
        rb3.setTextColor(Color.RED);
        rb4.setTextColor(Color.RED);

        switch (currentQuestion.getNranswer()) {
            case 1:
                rb1.setTextColor(Color.GREEN);
                textViewQuestion.setText("Resposta A está certa");
                break;

            case 2:
                rb2.setTextColor(Color.GREEN);
                textViewQuestion.setText("Resposta B está certa");
                break;

            case 3:
                rb3.setTextColor(Color.GREEN);
                textViewQuestion.setText("Resposta C está certa");
                break;

            case 4:
                rb4.setTextColor(Color.GREEN);
                textViewQuestion.setText("Resposta D está certa");
                break;
        }

        if(questionCounter < questionCounterTotal) {
            button_next.setText("Próxima");
        } else {
            button_next.setText("Finalizar");
        }
    }

    private void showNextQuestion(){
        rb1.setTextColor(txtColorDefaultRB);
        rb2.setTextColor(txtColorDefaultRB);
        rb3.setTextColor(txtColorDefaultRB);
        rb4.setTextColor(txtColorDefaultRB);
        rb_options.clearCheck();

        //Se ainda existem perguntas
        if(questionCounter < questionCounterTotal) {
            // Recuperar próxima pergunta
            currentQuestion = quizList.get(questionCounter);
            textViewQuestion.setText(currentQuestion.getQuestion());

            rb1.setText(currentQuestion.getOption1());
            rb2.setText(currentQuestion.getOption2());
            rb3.setText(currentQuestion.getOption3());
            rb4.setText(currentQuestion.getOption4());
            questionCounter++;

            textViewQuestionCounter.setText("Questão " + questionCounter + "/" + questionCounterTotal);
            answered = false;
            button_next.setText("Confirma");
        } else {
            finish();
        }
    }
}
