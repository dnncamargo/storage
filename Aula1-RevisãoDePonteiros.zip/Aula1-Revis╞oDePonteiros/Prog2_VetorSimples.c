/* ********************************************************************* */
/* Disciplina: Estruturas de Dados 2 - UVA                              */
/* Professor:Andr� Lucio                                                       */ 
/* Aula: 1                                                               */
/* ID Programa: Prog2                                                    */
/* Objetivo de Programa: Calcular a m�dia aritm�tica de 10 alunos        */
/* T�pico da Disciplina: Revis�o de Ponteiros                           */
/*                        (Ponteiros como par�metros de fun��o)         */
/* OBS: Neste exemplo ainda n�o usamos fun��es                           */
/* ********************************************************************* */

#include <stdio.h>

int main ( void )
{
	float notas[10];
	float media;
	int i;
	
	/* leitura dos valores */
	for (i = 0; i < 10; i++) 
		scanf("%f", &notas[i]);
	
	/* c�culo da m�dia */
	media = 0.0; 

	for (i = 0; i < 10; i++)
		media = media + notas[i];

	media = media / 10; /* calcular a m�dia */
	printf ( "Media = %f \n", media);
	return 0;
}
