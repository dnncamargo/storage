/* ********************************************************************* */
/* Disciplina: Estruturas de Dados 2 - UVA
/* Professor: Andr� Lucio                                                */ 
/* Objetivo de Programa: Inserir v�rios alunos em um vetor din�mico de   */
/*                       structs est�ticos. A inser��o dos dados dos alu-*/
/*                       ser� feita com uma fun��o que retorna o n�mero  */
/*                       de alunos inseridos (passagem de  par�metro de  */
/*                       vetor � sempre por refer�ncia)                  */
/* T�pico da Disciplinas Revis�o do uso de Ponteiros                     */
/* ********************************************************************* */

#include <stdio.h>
#include <stdlib.h>

 typedef struct aluno {
    char nome[40];
    float A1,A2,A3,media;   
 }Aluno,* PAluno;
/* Com o uso do typedef uma vari�vel do tipo "struct aluno" pode ser declarada
 apenas como "Aluno" e um ponteiro para esta estrutura como "PAluno"*/

PAluno incluir_aluno(int* num_alunos)
{
    int i;
    PAluno pa;
    //num_alunos � uma vari�vel que ser� lida para guardar o n�mero de alunos inseridos 
    printf("Informe o numero de alunos a serem inseridos: ");
    scanf("%d",num_alunos);
    pa = (PAluno) malloc((*num_alunos)*sizeof(Aluno));
    if (pa == NULL){
       printf("FALTOU MEMORIA");
       exit(1);     
    }
        
    for(i=0;i<(*num_alunos);i++)
    {     
      printf("Informe o nome do Aluno: "); 
      scanf(" %[^\n]",pa[i].nome);
      printf("Informe a nota da A1: "); 
      scanf("%f",&pa[i].A1);  
      printf("Informe a nota da A2: ");   
      scanf("%f",&pa[i].A2);
      printf("Informe a nota do A3: ");     
      scanf("%f",&pa[i].A3);
    }

    /* Nesta vers�o podemos usar o "." para acessar as vari�veis do struct, pois
       o vetor  cont�m estruturas est�ticas e o uso dos colchetes [i] permite
       acessar diretamente o conte�do da c�lula de um vetor */

   /*O & foi usado, pois a fun��o "scanf" necessita saber o endere�o da vari�vel.
   No caso do nome n�o foi necess�rio, pois em C um String � tratado como um vetor
   de caracteres e o nome dado a um vetor sempre representa o endere�o
   da sua primeira posi��o.*/
      
   return pa;  
}

void imprimir_alunos(int num_alunos, PAluno pa)
{
  int i;                       
  for(i=0;i<num_alunos;i++)
  {     
    printf("Nome: %s A1: %.2f  A2: %.2f  A3: %.2f Media: %.2f\n",pa[i].nome,pa[i].A1,pa[i].A2,pa[i].A3,pa[i].media);
  }                                         
}

void media_alunos(int num_alunos, PAluno pa)
{
  int i;

  for(i=0;i<num_alunos;i++)
  {     
        pa[i].media = (pa[i].A1 + pa[i].A2 + pa[i].A3)/3;       
  }                                         
}

int main(int argc, char *argv[])
{
   PAluno alunos; 
   int qtd_alunos;
   
   alunos = incluir_aluno(&qtd_alunos); //ATEN��O nesta vers�o a fun��o incluir passou a retornar o ponteiro para o in�cio do vetor
   //, pois a aloca��o din�mica do vetor foi feita dentro da fun��o e o escopo global n�o iria visualizar este endere�o, ocasionando erro de execu��o.
   media_alunos(qtd_alunos, alunos);
   imprimir_alunos(qtd_alunos, alunos);   
      
   system("PAUSE");	
   return 0;
}
