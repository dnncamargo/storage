/* ********************************************************************* */
/* Disciplina: Estruturas de Dados 2 - UVA                                */
/* Professor:Andr� Lucio                                                       */ 
/* Aula: 1                                                               */
/* ID Programa: Prog3                                                    */
/* Objetivo de Programa: Calcular a m�dia aritm�tica de n alunos         */
/* T�pico da Disciplinas: Revis�o de Ponteiros                           */  
/*			  (Vetor como par�metros de fun��es e Aloca��es   */
/*                        Din�mica de vetores - malloc)                  */
/* ********************************************************************* */

#include <stdio.h>
#include <stdlib.h>

float media;

float calc_media (int n, float* notas) {
	int j;
	float soma = 0.0;
	for (j = 0; j < n; j++)
		soma += notas[j];
	return soma/n;
}

void alterar(int total_alunos, float* N){
		
	int id_aluno;
	float nova_nota;

	printf("Digite o codigo do aluno a ser alterado: ");	
	scanf("%d",&id_aluno);
	printf("Digite a nova nota: ");	
	scanf("%f",&nova_nota);
	printf("Alterar o ID %d colocando a nova nota como %f\n",id_aluno,nova_nota);	

	if (id_aluno <= total_alunos){
		N[id_aluno-1] = nova_nota;
		media = calc_media(total_alunos,N);
		printf("Alteracao efetuada com sucesso. A m�dia foi recalculada\n");
	}else
		printf("Erro: �ndice inv�lido\n");
	}

void listar (int total_alunos, float *N){
int i;
	for (i=0; i<total_alunos;i++)
		printf("Nota do aluno %d = %f \n",i+1,N[i] );		
	
}

int main ( void )
{
	int i;
	int total_alunos;
	float *notas;

	printf("informe o total de alunos - ");
	scanf("%d",&total_alunos);

	notas = (float*) malloc(total_alunos*sizeof(float));
	if (notas==NULL)
	{
		printf("Memoria insuficiente.\n");
		exit(1); /* aborta o programa e retorna 1 para o sist. operacional */
	}

	/* leitura dos valores */
	for ( i = 0; i < total_alunos; i++ ){
		printf("Nota %d - ",i);
		scanf("%f",&notas[i]);
	}

	/* cálculo da m�dia */
	listar(total_alunos, notas);
	media = calc_media(total_alunos,notas);
	printf ( "Media = %f\n", media);
	alterar(total_alunos, notas); //notas contém o endere�o de mem�ria do primeiro elemento do vetor
	listar(total_alunos, notas);
	printf("Nova media = %f\n",media);
	system("PAUSE");

	return 0;
}
