/* ********************************************************************* */
/* Disciplina: Estruturas de Dados 2 - UVA                               */
/* Professor:André                                                       */ 
/* Aula: 1                                                               */
/* ID Programa: Prog1                                                    */
/* Objetivo de Programa: trocar o conte�do de duas variaveis             */
/* Topico da Disciplinas: Revisao de Ponteiros (Vari�veis             */
/*                        Tipo Ponteiro)                                 */
/* ********************************************************************* */
#include <stdio.h>

void troca (int *px, int *py )
{
	int temp;
	temp = *px; //uso do operador un�rio de cont�udo
	*px = *py;
	*py = temp;
}

int main ( void )
{
	int a = 5, b = 7;
	troca(&a, &b); /* passamos os endere�os das vari�veis */
	printf("%d %d \n", a, b);
	return 0;
}
