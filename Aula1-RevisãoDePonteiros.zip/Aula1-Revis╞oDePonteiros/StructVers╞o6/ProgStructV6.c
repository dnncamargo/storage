/* ********************************************************************* */
/* Disciplina: Estruturas de Dados 2 - UVA
/* Professor: Andr� Lucio                                                */ 
/* Objetivo de Programa: Inserir v�rios alunos em um vetor din�mico de   */
/*                       structs tamb�m alocados din�micamente.          */
/* T�pico da Disciplinas Revis�o do uso de Ponteiros                     */
/* ********************************************************************* */

#include <stdio.h>
#include <stdlib.h>

 typedef struct aluno {
    char nome[40];
    float A1,A2,A3,media;   
 }Aluno,*PAluno,**PPAluno;
/* Com o uso do typedef uma vari�vel do tipo "struct aluno" pode ser declarada
 apenas como "Aluno" e um ponteiro para esta estrutura como "PAluno" e um ponteiro
 de ponteiro para a estrutura como "PPAluno"*/

inicializa_vetor(int num_alunos, PPAluno ppa)
{
  int i;
  for(i=0;i<num_alunos;i++)
  {
    ppa[i] = NULL;             
  }
                                       
}

PPAluno incluir_aluno(int num_alunos)
{
    int i;
    PPAluno ppa;
    //alocar o vetor de estruturas
    ppa = (PPAluno) malloc(num_alunos*sizeof(PAluno));   
    if (ppa == NULL)
    {
         printf("\n\nMemoria insuficiente\n\n");
         exit(1);           
    }
    
    //este procedimento aponta todas as c�lulas do vetor para NULL
    inicializa_vetor(num_alunos, ppa);
                
    for(i=0;i<num_alunos;i++)
    {       
        ppa[i] = (PAluno) malloc(sizeof(Aluno));   
        if (ppa == NULL)
        {
           printf("\n\nMemoria insuficiente\n\n");
           exit(1);           
        }
      
        printf("Informe o nome do Aluno: "); 
        scanf(" %[^\n]",ppa[i]->nome);
        printf("Informe a nota da A1: "); 
        scanf("%f",&ppa[i]->A1);  
        printf("Informe a nota da A2: ");   
        scanf("%f",&ppa[i]->A2);
        printf("Informe a nota do A3: ");     
        scanf("%f",&ppa[i]->A3);   
    }
                   
   return ppa;  
}

void imprimir_alunos(int num_alunos, PPAluno ppa)
{
  int i;                       
  for(i=0;i<num_alunos;i++)
  {     
    printf("Nome: %s A1: %.2f  A2: %.2f  A3: %.2f \n",ppa[i]->nome,ppa[i]->A1,ppa[i]->A2,ppa[i]->A3);
  }                                         
}

void media_alunos(int num_alunos, PPAluno ppa)
{
  int i;

  for(i=0;i<num_alunos;i++)
  {     
        ppa[i]->media = (ppa[i]->A1 + ppa[i]->A2 + ppa[i]->A3)/3;       
  }                                         
}

int main(int argc, char *argv[])
{
   PPAluno alunos; // a vari�vel "alunos" foi declarada j� usando a redefini��o de tipo
   int qtd_alunos;

   //qtd_alunos � uma vari�vel que ser� lida para guardar o n�mero de alunos inseridos 
   printf("Informe o numero de alunos a serem inseridos: ");
   scanf("%d",&qtd_alunos);

   alunos = incluir_aluno(qtd_alunos); 
   media_alunos(qtd_alunos,alunos);
   imprimir_alunos(qtd_alunos,alunos);   
      
   system("PAUSE");	
   return 0;
}
