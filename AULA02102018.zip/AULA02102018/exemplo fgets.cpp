//exemplo leitura (entrada) getc fgetc
#include<stdio.h>
#include<stdlib.h>
int main(){
	char nome[20];
	int i=0;
	printf("Digite o seu nome e + um sobrenome:\n");
	fgets(nome,20,stdin);   //recebe 3 par�metros 
	
	printf("Nome: %s",nome);
	printf("Digite o seu nome e + um sobrenome:\n Novamente - Quero mostrar algo interessante");
	printf("Digite o seu nome e + um sobrenome:\n");
	fgets(nome,10,stdin);   // limitei a leitura.
	printf("Nome: %s",nome);
	return 0;
}
