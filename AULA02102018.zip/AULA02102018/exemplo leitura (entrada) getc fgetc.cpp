//exemplo leitura (entrada) getc fgetc
#include<stdio.h>
#include<stdlib.h>
int main(){
	char nome[20];
	int i=0;
	printf("Digite o seu nome e + um sobrenome\n");
	while((nome[i] = fgetc (stdin))!='\n'){
		++i;
	}
	nome[i]= '\0'; // para colocar o carcter nulo na ultima posi��o apos terminar o programa.
	printf("%s",nome);
	return 0;
}
