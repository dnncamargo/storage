//exemplo leitura de caracter- problema com getchar() - solu��o criar uma fun��o para limpar
#include<stdio.h>
#include<stdlib.h>
void limparBuffer(void){
	char c;
	while((c=getchar()) != '\n' && c != EOF);
}
int main(void){
	char x, y, z;
	x=getchar();
	limparBuffer();
	y=getchar();
	limparBuffer();
	z=getchar();
	limparBuffer();
	
	printf("%c", x);
	printf("%c", y);
	printf("%c", z);
	return 0;
}


