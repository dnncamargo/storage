//exemplo leitura de caracter- solu��o 1
#include<stdio.h>
#include<stdlib.h>
int main(){
	char ch;
	int i;
	char nome[20];
	printf("Digite o seu nome");
	//scanf("%s",nome);
	fgets(nome,20,stdin);
	printf("%s\n",nome);
	
	for(i=0;i<5;i++){
		printf("Digite o %d caracter:\n", i +1);
		scanf("%c",&ch);
		setbuf(stdin,NULL);
	}
	system("pause");
	return 0;
}

