//exemplo getchar()

#include <stdio.h>

int main(void){
    char letra;

    printf("Insira um caractere: ");
    letra = getchar();              //pega o caracter.
    printf("Vc digitou: '%c'", letra);
    return 0;
}


