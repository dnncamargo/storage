//exemplo leitura de caracter- problema com getchar() 
#include<stdio.h>
#include<stdlib.h>
int main(void){
	char x, y, z;
	x=getchar();
	fflush(stdin);// n�o funciona para limpar o buffer nesse caso.
	y=getchar();
	fflush(stdin);
	z=getchar();
	fflush(stdin);
	printf("%c", x);
	printf("%c", y);
	printf("%c", z);
		//scanf("%c",&ch);
		//setbuf(stdin,NULL);
	
	//system("pause");
	return 0;
}
