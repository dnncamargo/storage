//exemplo leitura de caracter.
#include<stdio.h>
#include<stdlib.h>
int main(){
	char ch;
	int i;
	for(i=0;i<5;i++){
		printf("Digite o %d caracter:\n", i +1);
		scanf("%c",&ch);
	}
	system("pause");
	return 0;
}

