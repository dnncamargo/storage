/* ********************************************************************* */
/* Disciplina: Estrutura de Dados 2                                      */
/* Professor: Andr�                                                      */ 
/* Objetivo de Programa: Implementa��o da TAD Matriz (vers�o 2 - matriz  */
/*                       como um vetor de vetor - ponteiro de ponteiro)  */                          
/* T�pico da Disciplina: Tipos Abstratos de Dados                        */
/* ********************************************************************* */

#include <stdio.h>
#include <stdlib.h>
#include "Matriz.h"

/* Estrutura utilizada*/
struct matriz {
       int lin;
       int col;
       float** v;
};

/* Fun��o que cria a Matriz*/
Matriz* cria (int m, int n) {
        int i;
        Matriz* mat = (Matriz*) malloc(sizeof(Matriz));
        if (mat == NULL) {
           printf("Mem�ria insuficiente!\n");
           exit(1);
        }
        mat->lin = m;
        mat->col = n;
        mat->v = (float**) malloc(m*sizeof(float*));
        for (i=0; i<m; i++)
            mat->v[i] = (float*) malloc(n*sizeof(float));
        return mat;
}

/* Procedimento que libera a �rea de mem�ria reservada para a estrutura Matriz*/
void libera (Matriz* mat) {
     int i;
     for (i=0; i<mat->lin; i++)
          free(mat->v[i]);
     free(mat->v);
     free(mat);
}

/* Fun��o que retorna o elemento de uma posi��o da matriz. */
float acessa (Matriz* mat, int i, int j) {
      if (i<0 || i>=mat->lin || j<0 || j>=mat->col) {
         printf("Acesso inv�lido!\n");
         exit(1);
      }
      return mat->v[i][j];
}

/* Procedimento que atribui um valor a uma posi��o da matriz. */
void atribui (Matriz* mat, int i, int j, float v) {
     if (i<0 || i>=mat->lin || j<0 || j>=mat->col) {
        printf("Atribui��o inv�lida!\n");
        exit(1);
     }
     mat->v[i][j] = v;
}

/* Func�o que retorna o n�mero de linhas da matriz */
int linhas (Matriz* mat) {
    return mat->lin;
}

/* Func�o que retorna o n�mero de colunas da matriz */
int colunas (Matriz* mat) {
    return mat->col;
}
