/* ********************************************************************* */
/* Disciplina: Estrutura de Dados 2                                      */
/* Professor: Andr�                                                      */ 
/* Objetivo de Programa: Implementa��o da TAD Matriz (vers�o 1 - matriz  */
/*                       como um vetor unidimencional)                   */
/* T�pico da Disciplina: Tipos Abstratos de Dados                        */
/* ********************************************************************* */

#include <stdio.h>
#include <stdlib.h>
#include "Matriz.h"

/* Estrutura utilizada*/
struct matriz {
       int lin;
       int col;
       float* v;
};

/* Fun��o que cria a Matriz*/
Matriz* cria (int m, int n) {
        Matriz* mat = (Matriz*) malloc(sizeof(Matriz));

        if (mat == NULL) {
           printf("Mem�ria insuficiente!\n");
           exit(1);
        }

        mat->lin = m;
        mat->col = n;
        mat->v = (float*) malloc(m*n*sizeof(float));
        return mat;
}

/* Procedimento que libera a �rea de mem�ria reservada para a estrutura Matriz*/
void libera (Matriz* mat){
     free(mat->v);
     free(mat);
}

/* Fun��o que retorna o elemento de uma posi��o da matriz. */
float acessa (Matriz* mat, int i, int j) {
      int k; /* �ndice do elemento no vetor */
      if (i<0 || i>=mat->lin || j<0 || j>=mat->col) {
         printf("Acesso inv�lido!\n");
         exit(1);
      }
      k = i*mat->col + j;
      return mat->v[k];
}

/* Procedimento que atribui um valor a uma posi��o da matriz. */
void atribui (Matriz* mat, int i, int j, float v) {
     int k; /* �ndice do elemento no vetor */
     if (i<0 || i>=mat->lin || j<0 || j>=mat->col) {
        printf("Atribui��o inv�lida!\n");
        exit(1);
     }
     k = i*mat->col + j;
     mat->v[k] = v;
}

/* Func�o que retorna o n�mero de linhas da matriz */
int linhas (Matriz* mat) {
    return mat->lin;
}

/* Func�o que retorna o n�mero de colunas da matriz */
int colunas (Matriz* mat) {
    return mat->col;
}
