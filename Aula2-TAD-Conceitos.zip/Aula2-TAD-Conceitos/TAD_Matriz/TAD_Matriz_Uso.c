/* ********************************************************************* */
/* Disciplina: Estrutura de Dados 2                                      */
/* Professor: Andr� Lucio                                                */ 
/* Objetivo de Programa: Utilizar os servicos da TAD Matriz              */
/* T�pico da Disciplina: Tipos Abstratos de Dados                        */
/* ********************************************************************* */

#include "Matriz.h"

int main(void){
    
  Matriz * m1 = cria(2,3);
  
  printf("Total de linhas = %d     Total de colunas = %d\n\n",linhas(m1),colunas(m1));
  
  atribui(m1,0,1,23.0);
  
  printf("Valor na posicao [0,1]: %f\n\n",acessa(m1,0,1));
  
  system("PAUSE");  
  
  libera(m1);
    
  return 0;

}
