/* **********************************************************************/
/* Disciplina: Estrutura de Dados 2                                      */
/* Professor:Andre                                                      */ 
/* Objetivo de Programa: Interface da TAD ponto                         */
/* Topico da Disciplina: Tipos Abstratos de Dados                     */
/* **********************************************************************/

/* TAD: Ponto (x,y) */
/* Tipo exportado */

typedef struct ponto Ponto;

/* Note que a composição da estrutura Ponto (struct ponto) não é exportada pelo módulo. Dessa forma, os demais módulos que usarem esse TAD não poderão acessar diretamente os campos dessa estrutura. */

/* Funções exportadas */

/* Função cria -Aloca e retorna um ponto com coordenadas (x,y)  */

Ponto* cria (float x, float y);

/* Função libera - Libera a memória de um ponto previamente criado. */

void libera (Ponto* p);

/* Função acessa - Devolve os valores das coordenadas de um ponto */

void acessa (Ponto* p, float* x, float* y);

/* Função atribui -  Atribui novos valores às coordenadas de um ponto */

void atribui (Ponto* p, float x, float y);

/* Função distancia - Retorna a distância entre dois pontos */

float distancia (Ponto* p1, Ponto* p2);
