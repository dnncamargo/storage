/* ********************************************************************* */
/* Disciplina: Estrutura de Dados 2                                      */
/* Professor: Andr� Lucio                                                */ 
/* Objetivo de Programa: Implementacao da TAD ponto                      */
/* T�pico da Disciplina: Tipos Abstratos de Dados                        */
/* ********************************************************************* */


#include <stdlib.h> /* malloc, free, exit */
#include <stdio.h> /* printf */
#include <math.h> /* sqrt */
#include "Ponto.h"

struct ponto {
	float x;
	float y;
};

Ponto* cria (float x, float y) {

	Ponto* p = (Ponto*) malloc(sizeof(Ponto));

	if (p == NULL) {
		printf("Memoria insuficiente!\n");
		exit(1);
	}

	p->x = x;
	p->y = y;
	return p;
}

void libera (Ponto* p){
	free(p);
}

void acessa (Ponto* p, float* x, float* y) {
	*x = p->x;
	*y = p->y;
}

void atribui (Ponto* p, float x, float y) {
	p->x = x;
	p->y = y;
}

float distancia (Ponto* p1, Ponto* p2) {
	float dx,dy, dist;
	dx = p2->x - p1->x;
	dy = p2->y - p1->y;
	dist = (float) sqrt(dx*dx + dy*dy);
	return dist;
}
