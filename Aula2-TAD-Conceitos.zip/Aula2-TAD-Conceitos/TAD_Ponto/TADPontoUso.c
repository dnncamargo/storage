/* ********************************************************************* */
/* Disciplina: Estrutura de Dados 2                                      */
/* Professor: Andr� Lucio                                                */ 
/* Objetivo de Programa: Utilizar os servicoss da TAD ponto              */
/* T�pico da Disciplina: Tipos Abstratos de Dados                        */
/* ********************************************************************* */

#include <stdio.h>
#include <stdlib.h>
#include "Ponto.h"

int main(void){

	Ponto *P1, *P2;
	float x,y,D;

	/*Cria ponto 1 */
	printf("Informe a coordenada X do ponto 1: ");
	scanf("%f",&x);
	printf("Informe a coordenada Y do ponto 1: ");
	scanf("%f",&y);
	P1 = cria (x,y);
	/*Acessa as coordenadas do ponto 1 */
	acessa(P1,&x,&y);
	/*Atribui valor para as coordenadas do ponto 1 */
	printf("P1 = (%.2f,%.2f)\n",x,y);
	/*Alterar o ponto 1*/
	printf("Informe a nova coordenada X do ponto 1: ");
	scanf("%f",&x);
	printf("Informe a nova coordenada Y do ponto 1: ");
	scanf("%f",&y);
	atribui(P1,x,y);
	/*Acessa as coordenadas do ponto 1 */
	acessa(P1,&x,&y);
	printf("P1 = (%.2f,%.2f)\n",x,y);

	/*Cria ponto 2 */
	printf("Informe a coordenada X do ponto 2: ");
	scanf("%f",&x);
	printf("Informe a coordenada Y do ponto 2: ");
	scanf("%f",&y);
	P2 = cria (x,y);
	/*Acessa as coordenadas do ponto 2 */
	acessa(P2,&x,&y);
	/*Atribui valor para as coordenadas do ponto 2 */
	printf("P2 = (%.2f,%.2f)\n",x,y);
	/*Alterar o ponto 2*/
	printf("Informe a nova coordenada X do ponto 2: ");
	scanf("%f",&x);
	printf("Informe a nova coordenada Y do ponto 2: ");
	scanf("%f",&y);
	atribui(P2,x,y);
	/*Acessa as coordenadas do ponto 2 */
	acessa(P2,&x,&y);
	printf("P2 = (%.2f,%.2f)\n",x,y);

	D = distancia (P1,P2);
	printf("Distancia entre os pontos 1 e 2  = %.2f\n",D);
    
    
	libera (P1);
	libera (P2);
    system("PAUSE"); 

	return 0;

}
